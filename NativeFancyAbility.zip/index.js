const request = require('request');
 
request(' https://developer.huawei.com/consumer/en/', function(err, res, body) {
    console.log(body);
});
